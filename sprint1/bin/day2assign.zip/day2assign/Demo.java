package day2assign;

public interface Demo {
	public int convetStringToNumber(String x);
}
