package day2assign.prob2;

public interface Demo {
	public void printDetail(Student student);
}
